//VARIABLES
var likes = 0;
var fans = 0;
var doublefans = 0;
var superfans = 0;
var doublesuperfans = 0;
var megafans = 0;
var doublemegafans = 0;
var bots = 0;
var doublebots = 0;
var doubleclicks = 0;
var number = 1;

var nextCostAddClick = Math.floor(20000 * Math.pow(1.1,number));
	document.getElementById('addClickCost').innerHTML = nextCostAddClick;
var nextCostDoubleClick = Math.floor(40000 * Math.pow(1.1,number));
	document.getElementById('doubleClickCost').innerHTML = nextCostDoubleClick;

//CONFIRMATION TO RESET THE GAME
function resetConfirm() {
    var resetAlert = confirm("Do you really want to reset the game?");
    if (resetAlert == true) {
        resetGame();
    }
}

//RESET THE GAME
function resetGame(){
    likes = 0;
	fans = 0;
	doublefans = 0;
	superfans = 0;
	doublesuperfans = 0;
	megafans = 0;
	doublemegafans = 0;
	bots = 0;
	doublebots = 0;
	number = 1;
	doubleclicks = 0;
	fanCost = 10;
	doubleFanCost = 20;
	superFanCost = 100;
	doubleSuperFanCost = 200;
	megaFanCost = 500;
	doubleMegaFanCost = 1000;
	botCost = 5000;
	doubleBotCost = 10000;
	addClickCost = 20000;
	doubleClickCost = 40000;
	document.getElementById("likes").innerHTML = 'You have: ' + likes + ' likes!';
	document.getElementById('fans').innerHTML = fans;
	document.getElementById('fanCost').innerHTML = fanCost;
	document.getElementById('doublefans').innerHTML = doublefans;
	document.getElementById('doubleFanCost').innerHTML = doubleFanCost;
	document.getElementById('superfans').innerHTML = superfans;
	document.getElementById('superFanCost').innerHTML = superFanCost;
	document.getElementById('doublesuperfans').innerHTML = doublesuperfans;
	document.getElementById('doubleSuperFanCost').innerHTML = doubleSuperFanCost;
	document.getElementById('megafans').innerHTML = megafans;
	document.getElementById('megaFanCost').innerHTML = megaFanCost;
	document.getElementById('doublemegafans').innerHTML = doublemegafans;
	document.getElementById('doubleMegaFanCost').innerHTML = doubleMegaFanCost;
	document.getElementById('bots').innerHTML = bots;
	document.getElementById('botCost').innerHTML = botCost;
	document.getElementById('doublebots').innerHTML = doublebots;
	document.getElementById('doubleBotsCost').innerHTML = doubleBotCost;
	document.getElementById('number').innerHTML = number;
	document.getElementById('addClickCost').innerHTML = addClickCost;
	document.getElementById('doubleclicks').innerHTML = doubleclicks;
	document.getElementById('doubleClickCost').innerHTML = doubleClickCost;
};

//CLICK FUNCTION
function likeClick(number){
    likes = likes + number;
	document.getElementById("likes").innerHTML = 'You have: ' + likes + ' likes!';
};

//SHOP

//+1 FAN
function addFan(){
    var fanCost = Math.floor(10 * Math.pow(1.1,fans));     //adds a cost amount to each unit purchased
    if(likes >= fanCost){                                   //check if the player has enough likes
        fans = fans + 1;                                   //item number increases
    	likes = likes - fanCost;                          //spend the likes
        document.getElementById('fans').innerHTML = fans;  //updates the number of units purchased
        document.getElementById('likes').innerHTML = 'You have: ' + likes + ' likes!';  //update likes
    }
	else {
		alert('You have not got enough likes.')      //if you do not have enough likes, show an alert
	};
	var nextCostFan = Math.floor(10 * Math.pow(1.1,fans));
    document.getElementById('fanCost').innerHTML = nextCostFan;  //update the number for the player
};

//x2 FANS
function doubleFan(){
    var doubleFanCost = Math.floor(20 * Math.pow(1.1,doublefans));
    if(likes >= doubleFanCost){
        doublefans = doublefans + 1;
		fans = fans * 2;                                   //doubles the number of units of the respective item
    	likes = likes - doubleFanCost;
        document.getElementById('doublefans').innerHTML = doublefans;
		document.getElementById('fans').innerHTML = fans;  //updates the number of units purchased with x2
		var nextCostFan = Math.floor(10 * Math.pow(1.1,fans));
		document.getElementById('fanCost').innerHTML = nextCostFan;//updates the next cost
        document.getElementById('likes').innerHTML = 'You have: ' + likes + ' likes!';
    }
	else {
		alert('You have not got enough likes.')
	};
    var nextCostDoubleFan = Math.floor(20 * Math.pow(1.1,doublefans));
    document.getElementById('doubleFanCost').innerHTML = nextCostDoubleFan;
};

//+1 SUPER FAN
function addSuperFan(){
    var superFanCost = Math.floor(100 * Math.pow(1.1,superfans));
    if(likes >= superFanCost){
        superfans = superfans + 1;
    	likes = likes - superFanCost;
        document.getElementById('superfans').innerHTML = superfans;
        document.getElementById('likes').innerHTML = 'You have: ' + likes + ' likes!';
    }
	else {
		alert('You have not got enough likes.')
	};
	var nextCostSuperFan = Math.floor(100 * Math.pow(1.1,superfans));
    document.getElementById('superFanCost').innerHTML = nextCostSuperFan;
};

//x2 SUPER FANS
function doubleSuperFan(){
    var doubleSuperFanCost = Math.floor(200 * Math.pow(1.1,doublesuperfans));
    if(likes >= doubleSuperFanCost){
        doublesuperfans = doublesuperfans + 1;
		superfans = superfans * 2;
    	likes = likes - doubleSuperFanCost;
        document.getElementById('doublesuperfans').innerHTML = doublesuperfans;
		document.getElementById('superfans').innerHTML = superfans;
		var nextCostSuperFan = Math.floor(100 * Math.pow(1.1,superfans));
		document.getElementById('superFanCost').innerHTML = nextCostSuperFan;
        document.getElementById('likes').innerHTML = 'You have: ' + likes + ' likes!';
    }
	else {
		alert('You have not got enough likes.')
	};
    var nextCostDoubleSuperFan = Math.floor(200 * Math.pow(1.1,doublesuperfans));
    document.getElementById('doubleSuperFanCost').innerHTML = nextCostDoubleSuperFan;
};

//+1 MEGA FAN
function addMegaFan(){
    var megaFanCost = Math.floor(500 * Math.pow(1.1,megafans));
    if(likes >= megaFanCost){
        megafans = megafans + 1;
    	likes = likes - megaFanCost;
        document.getElementById('megafans').innerHTML = megafans;
        document.getElementById('likes').innerHTML = 'You have: ' + likes + ' likes!';
    }
	else {
		alert('You have not got enough likes.')
	};
    var nextCostMegaFan = Math.floor(500 * Math.pow(1.1,megafans));
    document.getElementById('megaFanCost').innerHTML = nextCostMegaFan;
};

//x2 MEGA FANS
function doubleMegaFan(){
    var doubleMegaFanCost = Math.floor(1000 * Math.pow(1.1,doublemegafans));
    if(likes >= doubleMegaFanCost){
        doublemegafans = doublemegafans + 1;
		megafans = megafans * 2;
    	likes = likes - doubleMegaFanCost;
        document.getElementById('doublemegafans').innerHTML = doublemegafans;
		document.getElementById('megafans').innerHTML = megafans;
		var nextCostMegaFan = Math.floor(500 * Math.pow(1.1,megafans));
		document.getElementById('megaFanCost').innerHTML = nextCostMegaFan;
        document.getElementById('likes').innerHTML = 'You have: ' + likes + ' likes!';
    }
	else {
		alert('You have not got enough likes.')
	};
    var nextCostDoubleMegaFan = Math.floor(1000 * Math.pow(1.1,doublemegafans));
    document.getElementById('doubleMegaFanCost').innerHTML = nextCostDoubleMegaFan;
};

//+1 BOT
function addBot(){
    var botCost = Math.floor(5000 * Math.pow(1.1,bots));
    if(likes >= botCost){
        bots = bots + 1;
    	likes = likes - botCost;
        document.getElementById('bots').innerHTML = bots;
        document.getElementById('likes').innerHTML = 'You have: ' + likes + ' likes!';
    }
	else {
		alert('You have not got enough likes.')
	};
    var nextCostBot = Math.floor(5000 * Math.pow(1.1,bots));
    document.getElementById('botCost').innerHTML = nextCostBot;
};

//x2 BOTS
function doubleBots(){
    var doubleBotsCost = Math.floor(10000 * Math.pow(1.1,doublebots));
    if(likes >= doubleBotsCost){
        doublebots = doublebots + 1;
		bots = bots * 2;
    	likes = likes - doubleBotsCost;
        document.getElementById('doublebots').innerHTML = doublebots;
		document.getElementById('bots').innerHTML = bots;
		var nextCostBot = Math.floor(5000 * Math.pow(1.1,bots));
		document.getElementById('botCost').innerHTML = nextCostBot;
        document.getElementById('likes').innerHTML = 'You have: ' + likes + ' likes!';
    }
	else {
		alert('You have not got enough likes.')
	};
    var nextCostDoubleBots = Math.floor(10000 * Math.pow(1.1,doublebots));
    document.getElementById('doubleBotsCost').innerHTML = nextCostDoubleBots;
};

//+1 CLICK
function addClick(){
    var addClickCost = Math.floor(20000 * Math.pow(1.1,number));
    if(likes >= addClickCost){
        number = number + 1;
    	likes = likes - addClickCost;
        document.getElementById('number').innerHTML = number;
		document.getElementById('addClickCost').innerHTML = nextCostAddClick;
        document.getElementById('likes').innerHTML = 'You have: ' + likes + ' likes!';
    }
	else {
		alert('You have not got enough likes.')
	};
    var nextCostAddClick = Math.floor(20000 * Math.pow(1.1,number));
    document.getElementById('addClickCost').innerHTML = nextCostAddClick;
};

//x2 CLICK
function doubleClick(){
    var doubleClickCost = Math.floor(40000 * Math.pow(1.1,number));
    if(likes >= doubleClickCost){
		doubleclicks = doubleclicks + 1;
        number = number * 2;
    	likes = likes - doubleClickCost;
		document.getElementById('doubleclicks').innerHTML = doubleclicks;
        document.getElementById('number').innerHTML = number;
		document.getElementById('doubleClickCost').innerHTML = nextCostDoubleClick;
        document.getElementById('likes').innerHTML = 'You have: ' + likes + ' likes!';
    }
	else {
		alert('You have not got enough likes.')
	};
    var nextCostDoubleClick = Math.floor(40000 * Math.pow(1.1,number));
    document.getElementById('doubleClickCost').innerHTML = nextCostDoubleClick;
};

//TIME INTERVAL (LIKES PER SECOND)
window.setInterval(function(){
	likeClick(fans);
}, 10000);
window.setInterval(function(){
	likeClick(superfans);
}, 1000);
window.setInterval(function(){
	likeClick(bots);
}, 10);