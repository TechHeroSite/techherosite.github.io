function showText() {
	document.querySelector("#HCR2Label").style.display = "block";
}

function hideText() {
	document.querySelector("#HCR2Label").style.display = "none";
}